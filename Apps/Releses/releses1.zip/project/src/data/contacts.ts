import { PoliceContact } from '../types/directory';

export const policeContacts: PoliceContact[] = [
  {
    id: 1,
    department: "Jefatura de Policía de Montevideo",
    unit: "Central de Comunicaciones",
    phone: "2030 4000",
    address: "San José 1126",
    zone: "Centro"
  },
  {
    id: 2,
    department: "Seccional 1ª",
    unit: "Comisaría",
    phone: "2915 7111",
    address: "25 de Mayo 501",
    zone: "Ciudad Vieja"
  },
  {
    id: 3,
    department: "Dirección Nacional de Bomberos",
    unit: "Central de Alarmas",
    phone: "2916 2222",
    address: "Paraguay 1138",
    zone: "Centro"
  }
];