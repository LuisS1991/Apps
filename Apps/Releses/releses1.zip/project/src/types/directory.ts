export interface PoliceContact {
  id: number;
  department: string;
  unit: string;
  phone: string;
  address: string;
  zone: string;
}