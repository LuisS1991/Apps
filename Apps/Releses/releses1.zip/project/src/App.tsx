import React, { useState } from 'react';
import { Phone } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { ContactCard } from './components/ContactCard';
import { policeContacts } from './data/contacts';
import { filterContacts } from './utils/search';

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredContacts = filterContacts(policeContacts, searchTerm);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-800 text-white py-6 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center mb-6">
            <Phone className="h-8 w-8 mr-3" />
            <h1 className="text-2xl font-bold">Guía Telefónica - Policía de Montevideo</h1>
          </div>
          <SearchBar searchTerm={searchTerm} onSearchChange={setSearchTerm} />
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {filteredContacts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No se encontraron resultados para su búsqueda.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredContacts.map(contact => (
              <ContactCard key={contact.id} contact={contact} />
            ))}
          </div>
        )}
      </main>

      <footer className="bg-gray-100 py-4 mt-auto">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} Jefatura de Policía de Montevideo</p>
        </div>
      </footer>
    </div>
  );
}

export default App;