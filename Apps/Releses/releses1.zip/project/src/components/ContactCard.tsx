import React from 'react';
import { Phone, MapPin, Building2 } from 'lucide-react';
import { PoliceContact } from '../types/directory';

interface ContactCardProps {
  contact: PoliceContact;
}

export function ContactCard({ contact }: ContactCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <h3 className="text-lg font-semibold text-gray-900 mb-2">{contact.department}</h3>
      <div className="space-y-2">
        <div className="flex items-center text-gray-600">
          <Building2 className="h-4 w-4 mr-2" />
          <span>{contact.unit}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <Phone className="h-4 w-4 mr-2" />
          <span>{contact.phone}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <MapPin className="h-4 w-4 mr-2" />
          <span>{contact.address}</span>
        </div>
        <div className="mt-2">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {contact.zone}
          </span>
        </div>
      </div>
    </div>
  );
}