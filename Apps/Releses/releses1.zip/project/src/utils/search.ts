import { PoliceContact } from '../types/directory';

export function filterContacts(contacts: PoliceContact[], searchTerm: string): PoliceContact[] {
  const normalizedSearch = searchTerm.toLowerCase().trim();
  
  if (!normalizedSearch) return contacts;
  
  return contacts.filter(contact => 
    contact.department.toLowerCase().includes(normalizedSearch) ||
    contact.unit.toLowerCase().includes(normalizedSearch) ||
    contact.zone.toLowerCase().includes(normalizedSearch) ||
    contact.address.toLowerCase().includes(normalizedSearch)
  );
}